#define _USE_MATH_DEFINES
#include <cmath>
#include <iostream>
#include <string>
#include <iomanip>

using std::string;
using std::istream;
using std::ostream;
using std::setprecision;
using std::fixed;
using std::showpoint;
using std::setw;

void calculate( istream& in, ostream& out );