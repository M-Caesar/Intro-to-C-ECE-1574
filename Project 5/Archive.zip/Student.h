#include <string>
#include <fstream>
#include <iostream>
#include <string>
using namespace std;

#ifndef __Student__
#define __Student__


const int HW_SIZE = 20;
const int PROJ_SIZE = 5;

class Student
{
private:
	string last;
	string first;
	double hwGrades[HW_SIZE];
	int hwCount;
	double projectGrades[PROJ_SIZE];
	int projectCount;
	double attendance;
	double midterm;
	double finalExam;

public:

	Student(string last="", string first="");

	void addHWGrade (double newGrade);
 	void addProjectGrade (double newGrade);
 
	void setAttendance (double attendance);
 
	void setMidtermGrade (double midterm);
 
	void setFinalExam (double finalExam);
 
	double getAverage () const;
 
	string getLastName () const;
 
	string getFirstName () const;
 
	void displayGrades (ostream &out) const;

};

#endif /* defined(__Fall14Project5__Student__) */