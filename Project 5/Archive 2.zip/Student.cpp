#include "Student.h"



Student::Student(string last, string first)
{
	this->last=last;
	this->first=first;

	hwCount = 0;
	projectCount = 0;
	attendance = 0;
	midterm = 0;
	finalExam = 0; 

}


void Student::addHWGrade (double newGrade)
{
	if (hwCount < HW_SIZE)
	{
		hwGrades[hwCount] = newGrade;
		hwCount++;
	}


}
void Student::addProjectGrade (double newGrade)
{
	if (projectCount < PROJ_SIZE)
	{
		projectGrades[projectCount] = newGrade;
		projectCount++;
	}

}
 
void Student::setAttendance (double attendance)
{
	this->attendance = attendance;

}
 
void Student::setMidtermGrade (double midterm)
{
	this->midterm = midterm;

}
 
void Student::setFinalExam (double finalExam)
{
	this->finalExam = finalExam;

}
 
double Student::getAverage () const
{
//--attendance calculation------------------------------

	double ATd = 0;
		// calculation of Attendance divided by 10

	  ATd = attendance / 10.0; 

	double AttendanceFinal =0;

	AttendanceFinal =ATd * .05;

// -- HW calculation------------------------------
	double totalHW = 0;

	for (int i = 0; i < hwCount; i++)
	{
		totalHW = totalHW + hwGrades[i];
	}

	double totalHWt = 0;
	totalHWt=(hwCount)*100;
	// totalHWt will calculate the X00 number such as 500 or 400 that the total will divide by. 
	//Since count starts at 0, there needs to be a +1 before being multiplied by 100

	double HWfinal = 0;

	HWfinal=totalHW/totalHWt;

	double Hwpercent=0;

	Hwpercent=HWfinal *.15;
// Project Calculation------------------------------
	double totalproj =0;
	for (int i = 0; i < projectCount; i++)
	{
		totalproj = totalproj + projectGrades[i];
	}

	double totalprojt= 0;

	totalprojt= (projectCount)*100;

	// totalprojt will calculate the X00 number such as 500 or 400 that the total will divide by. 
	//Since count starts at 0, there needs to be a +1 before being multiplied by 100
	double Projfinal=0;

	Projfinal=totalproj/totalprojt;

	double projpercent=0;

	projpercent=Projfinal *.4;

// - Midterm calculation------------------------------

	double midtermpercent=0;

	midtermpercent=(midterm / 100) *.2;

// - Final test calculation------------------------------

	double finalpercent=0;

	finalpercent=(finalExam / 100) *.2;

// Final average calc------------------------------

	double totalfinalfinal = 0;

	totalfinalfinal=(finalpercent + midtermpercent + projpercent + Hwpercent + AttendanceFinal)*100;

	return totalfinalfinal;

}
 
string Student::getLastName () const
{
	return last;

}
 
string Student::getFirstName () const
{
	return first;

}
 
void Student::displayGrades (ostream &out) const
{

	out << "Name: " << last << ", " <<first << endl;

	out << "Attendance: " << attendance << endl;

	out << "Midterm: " << midterm << endl;

	out << "Final: " << finalExam << endl;

	out<< "HWs: ";
	for (int i = 0; i < hwCount; i++)
	{
		out << hwGrades[i];
		if (i < hwCount-1)
		{
			out << ", ";
		}
		 
	}
	out << "\n";

	out << "Projects: ";
	for (int i = 0; i < projectCount; i++)
	{
		out << projectGrades[i];
		if (i < projectCount-1)
		{
			out << ", ";
		}
		
	}

	out << "\n";

	out << "Average: " << getAverage() <<"0";



	
}