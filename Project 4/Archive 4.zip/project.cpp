#include "runner.h"

void runRace( istream &in, ostream &out )
{
	out << fixed << showpoint << setprecision(2); 

	//Widget myArray[10];
	//int count = 0;

	// Does this work? Why int though? Maybe string or something?
	Widget *myArray;
	int size = 10;
	int count = 0;

	myArray = new Widget [size];

	string name;

	string command;

	in.ignore(256,':');

    in >> name;

    readfilename( name, myArray, count, size);

	in >> command; 

	while ( !in.fail() )
	{
		//out << command << endl;

		if (command == "find-name")
		{ 
			namefunction(in, myArray, out, count, size, command );

		}
		else if (command == "find-place")
		{
			placefunction(in, myArray, out, count, command );

		}
		
		else if (command == "find-bib")
		{
			bibfunction(in, myArray, out, count, command );

		}
		

		in >> command;

		
	}



}

void readfilename(string name, Widget *&myArray, int &count, int &size)
	{
		count =0;

	    ifstream in;

		in.open( name.c_str() );

		Widget storage;

		int hour =0;
		int min = 0;
		int sec = 0;

		char c;

		// Note for professor
		// Getline isn't working correctly. Crashing program? 
		// is the ignoring correct?

		getline(in, storage.last, ',');
		//cout << "the last name test is " << storage.last << endl;

		getline(in, storage.first, ',');
		//cout << "the first name test is " << storage.first << endl;


		getline(in, storage.bib, ',');
		//cout << "the bib name test is " << storage.bib << endl;

		getline(in, storage.sex, ',');
		//cout << "the sex name test is " << storage.sex << endl;

		in >> hour >> c >> min >> c >> sec;
		in.get();
		storage.clock = hour*3600+min*60+sec;
		//cout << "the clock name test is " << storage.clock << endl;

		in >> hour >> c >> min >> c >> sec;
		storage.chip = hour*3600+min*60+sec;
		//cout << "the chip name test is " << storage.chip << endl;

		in.get();

		while(!in.fail())
		{
			
			// I'm probably gonna need something for growing here right?
			// ......
			// hmmm....ummm.....yeah. Let me try this

			// eye of newt, toe of frog, wool of bat. For a charm of powerful trouble
			// make this array DOUBLE! *poof*

			if (count == size)
			{
				//cout << "\t Shoutout if grow works" << endl;
				grow(myArray, size);
				
			}
			
			{

				myArray[count] = storage;
				count++;
				
				getline(in, storage.last, ',');
				//cout << "\n" << "the last name test is '" << storage.last << "'"<< endl;

				getline(in, storage.first, ',');
				//cout << "the first name test is '" << storage.first << "'"<< endl;


				getline(in, storage.bib, ',');
				//cout << "the bib name test is '" << storage.bib << "'"<<endl;

				getline(in, storage.sex, ',');
				//cout << "the sex name test is '" << storage.sex << "'"<< endl;

				in >> hour >> c >> min >> c >> sec;
				in.get();
				storage.clock = hour*3600+min*60+sec;
				//cout << "the clock name test is " << storage.clock << endl;

				in >> hour >> c >> min >> c >> sec;
				storage.chip = hour*3600+min*60+sec;
				//cout << "the chip name test is " << storage.chip << endl;

				in.get();
				
			}
			
			for (int i= 0; i < count; i++)
			{	
					
				for (int j=i; j < count; j++)
					if(myArray[i].chip > myArray[j].chip)
					{
						Widget temp = myArray[i];
						myArray[i]=myArray[j];
						myArray[j]=temp;
					}
					
			}
				

			
		}

		// Ummmmmm yeah. This part. I have no idea what I am doing
		// On the internet, nobody knows you're a dog

		/*
		maxnumber = myArray[1].chip;

		i=2;

		while (i <= count)
		{
			if myArray[i].chip < maxnumber
			{
				myArray[i] = myArray[(i-1)];

			}
			i = i+1
		}
		*/
		
	}


	// Please explain this....it's witchcraft

	void grow( Widget *&myArray, int &size)
	{

	int newSize = size * 2;
	Widget *temp = new Widget[newSize];

		for (int i=0; i<size; i++)
			temp[i]=myArray[i];

		
		size = size * 2; // size = size *2
		delete [] myArray; // gives back x's memory
		myArray = temp;

		temp = NULL; 

	}

	


	void namefunction(istream& in, Widget *myArray, ostream& out, int &count, int &size, string command)
	{
		string name;

		in >> name;
		//cout << "name of namefunction initial test " << name << endl;
		//cout << "tell me the current size " << size << "tell me the current count " << count << endl;

		bool namebool = false;

		// How do I loop through it as many times as I want? I'm sure this way isn't right
		// All the array are belong to me. But It's hard to use them effectively

		//int n = 0;
		out << command <<" "<<  name << endl;
		
		for ( int i=0; i<count ; i++)
		{
			


				if (myArray[i].last == name)
				{
					// ------------------ Clock Time Reformat
					int hour = myArray[i].clock/3600;


					int rem = myArray[i].clock % 3600;

					int minutes = rem/60;

					int seconds = rem % 60;

				
						

					
					//setw(2)<<setfill('O')<< minutes <<':'<<setw(2)<<seconds<<setfill(' ');

					// ------------------ Chip Time Reformat


					int hour2 = myArray[i].chip/3600;


					int rem2 = myArray[i].chip % 3600;

					int minutes2 = rem2/60;

					int seconds2 = rem2 % 60;

					// why does your result have the extra second decimal?
					
					out << i+1 <<" "<< name << ", "<< myArray[i].first <<" "<< myArray[i].bib <<" "<< myArray[i].sex <<" "<< hour << ":";
					if ( minutes < 10)
						out << "0";
					out << minutes << ":";
					if ( seconds < 10)
						out << "0";
					 out << seconds <<" "<< hour2 << ":";
					if (minutes2 < 10)
					 	out << "0";
					 out << minutes2 << ":";
					if (seconds2 <10 )
					 	out << "0";
					 out << seconds2 << endl;
					
					namebool = true;
				}

				
		}

		
		if (!namebool)
			{
				
				out << "Sorry, no runners with last name " << name << " were found." << endl;

			}
			


	}

	void placefunction(istream& in, Widget *myArray, ostream& out, int &count,string command )
	{
		int place;
		in >> place;

		bool placebool = false;
		//int i =0;

		if (place > 0 && place < count)
		{
			// ------------------ Clock Time Reformat
			place = place - 1;	
			int hour = myArray[place].clock/3600;


			int rem = myArray[place].clock % 3600;

			int minutes = rem/60;

			int seconds = rem % 60;

						// ------------------ Chip Time Reformat


			int hour2 = myArray[place].chip/3600;


			int rem2 = myArray[place].chip % 3600;

			int minutes2 = rem2/60;

			int seconds2 = rem2 % 60;

						// why does your result have the extra second decimal?
			out << command <<" "<<  place << endl;
			out << place+1 <<" "<< myArray[place].last << ", "<< myArray[place].first <<" "<< myArray[place].bib <<" "<< myArray[place].sex <<" "<< hour << ":"; 
			if ( minutes < 10)
				out << "0";
			out << minutes << ":";
			if ( seconds < 10)
				out << "0";
			 out << seconds <<" "<< hour2 << ":";
			if (minutes2 < 10)
			 	out << "0";
			 out << minutes2 << ":";
			if (seconds2 <10 )
			 	out << "0";
			out << seconds2 << endl;
					
			placebool = true;
			

		}


		if (!placebool)
		{
			out << command <<" "<<  place << endl;
			out << "Sorry, no runners with place " << place << " were found." << endl;
		}

	}
	


	void bibfunction(istream& in, Widget myArray[], ostream& out, int &count,string command )
	{
		string bib;
		in >> bib;

		bool bibbool = false;

		for ( int i=0; i<count ; i++)
		{
			


			if (myArray[i].bib == bib)
			{
					// ------------------ Clock Time Reformat
					int hour = myArray[i].clock/3600;


					int rem = myArray[i].clock % 3600;

					int minutes = rem/60;

					int seconds = rem % 60;

					// ------------------ Chip Time Reformat


					int hour2 = myArray[i].chip/3600;


					int rem2 = myArray[i].chip % 3600;

					int minutes2 = rem2/60;

					int seconds2 = rem2 % 60;

					// why does your result have the extra second decimal?
					out << command << " "<< bib << endl;
					out << i+1 <<" "<< myArray[i].last << ", "<< myArray[i].first <<" "<< myArray[i].bib <<" "<< myArray[i].sex <<" "<< hour << ":";
					if ( minutes < 10)
						out << "0";
					out << minutes << ":";
					if ( seconds < 10)
						out << "0";
					 out << seconds <<" "<< hour2 << ":";
					if (minutes2 < 10)
					 	out << "0";
					 out << minutes2 << ":";
					if (seconds2 <10 )
					 	out << "0";
					out << seconds2 << endl;
					
					bibbool = true;

			}
		}		

		if (!bibbool)
		{
			out << command << " "<< bib << endl;
			out << "Sorry, no runners with bib " << bib << " were found." << endl;
		}

	}

