#include <fstream>
#include <iostream>
#include <string>
#include <cctype>
#include <cmath>
#include <iomanip>
#include <algorithm>


using namespace std;


// These shouldn't all be strings now right?
struct Widget
{
	string last;
	string first;
	string bib;
	string sex;
	int clock; // string or int? Format is weird for chip and clock
	int chip;

};

void runRace( istream &in, ostream &out );

void readfilename(string name, Widget *&myArray, int &count, int &size);

void namefunction(istream& in, Widget *myArray, ostream& out, int &count, int &size,string command );

void placefunction(istream& in, Widget *myArray, ostream& out, int &count,string command );

void bibfunction(istream& in, Widget *myArray, ostream& out, int &count,string command );

void grow( Widget *&myArray, int &size);
//void sort(int x[], int &count);