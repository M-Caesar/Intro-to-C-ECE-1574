#include <iostream>
#include <string>

using std::istream;
using std::ostream;
using std::endl;
using std::string;

void computeResistance( istream& in, ostream& out );
