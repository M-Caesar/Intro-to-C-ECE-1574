#include "resistors.h"
using namespace std;

void computeResistance( istream& in, ostream& out )
{
	
	double resistor; // this is a double float for the resistor
	
	
	
	
	double count1 = 0;
	
	

	cout << "Please tell me the resistor value(s): ";
	in >> resistor; //prime
	while( !in.fail() )//test1
	{
	
		if (resistor == 0)
		{
			out << "--error--";
		}
		else
		{
		count1 = count1 + 1.0/resistor;
			
		}
		in >> resistor; //reprime
	}
	
	
	out << 1/count1;
	

}


