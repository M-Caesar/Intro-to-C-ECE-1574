#include "resistors.h"
using namespace std;

void computeResistance( istream& in, ostream& out )
{
	
	double resistor; // this is a double float for the resistor
	
	
	//int TotalSet=3;
	int initial=0;
	
	double count1 = 0;
	
	

	//cout << "Please tell me the resistor value(s): ";
	in >> resistor; //prime
	while( initial<=3 )//test1
	{
		count1 = count1 + 1.0/resistor;
			
		
		in >> resistor; //reprime
		initial = initial + 1;
	}
	
	
	//out << 1/count1;
	

	//if (count1 == 0);
	//{
		//out << "--error--";
	//}
	
		out << 1/count1;
	
	
}


