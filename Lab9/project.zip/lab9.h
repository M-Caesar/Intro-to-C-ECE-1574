#include <iostream>
#include <fstream>
#include <string>
using namespace std;



struct basicStruct
{
	
	string name;
	double number;
	
	
}; // <--- notice they end with a ; here 

void readData( istream& in, ostream& out);
