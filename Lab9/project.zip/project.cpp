#include <iostream>
#include "lab9.h"
#include <fstream>
using namespace std;

//const int ARRAY_SIZE = 10; //this is a global constant

void readData( istream& in, ostream& out )
{
	//basicStruct myData;
	//myData.name = 1;
	//myData.number = 1.0;

	basicStruct myArrayOfData[10];
	string Name;
	double Number;

	for (int i = 0; i<10; i++)
	{
		in >> Name;
		in >> Number;

		myArrayOfData[i].name = Name;
		myArrayOfData[i].number = Number;
	}

	out << "Index" << "\t" << "Name" << "\t" << "Number" << endl;

	for (int i = 0; i < 10; i++)
	{
		out << i << "\t" <<  myArrayOfData[i].name << "\t" << myArrayOfData[i].number << endl;
	}
/*
	out << "Index Name Number \n";
	for (int i = 0; i < 10; i++)
	{
		out << i << " " << myArrayOfData[i] << endl;
	}
	*/
}

	