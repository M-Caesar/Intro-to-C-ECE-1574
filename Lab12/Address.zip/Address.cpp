#include "Address.h"

Address::Address()
{
	firstName = "";
	lastName = "";
	address = "";
}

Address::Address ( string firstName, string lastName, string address)
{
	//hmm
}

string Address::getAddress	()
{
	return address;
}	

string Address::getFirstName()
{
	return firstName;
}

string Address::getLastName()
{
	return lastName;
}



void Address::setAddress(string newAddress)
{

}	

void Address::setFirstName(string newFirstName)
{

}

void Address::setLastName(string newLastName)
{

}