#include <fstream>
#include <iostream>
#include <string>
#include <cctype>
#include <cmath>
#include <iomanip>
#include <algorithm>


using namespace std;

void dynamic( istream& in, ostream& out );
void grow( int *&x, int &size);