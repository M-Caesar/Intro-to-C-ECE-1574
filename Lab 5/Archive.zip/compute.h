#define _USE_MATH_DEFINES
#include <cmath>
#include <iostream>
#include <string>
#include <iomanip>

using std::string;
using namespace std;
using std::istream;
using std::ostream;
using std::setprecision;
using std::fixed;
using std::showpoint;

using std::setw;

void compute( istream& in, ostream& out );
