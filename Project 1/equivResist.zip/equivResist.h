#include <iostream>
#include <string>

using std::istream;
using std::ostream;
using std::endl;
using std::string;

void equivalentResistance( istream& in, ostream& out );
